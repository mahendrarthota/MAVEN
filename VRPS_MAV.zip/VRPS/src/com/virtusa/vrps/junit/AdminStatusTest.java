package com.virtusa.vrps.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtusa.vrps.DAO.AdminStatusDAO;
import com.virtusa.vrps.DAO.IndividualDAO;
import com.virtusa.vrps.models.AdminStatus;
import com.virtusa.vrps.models.Application;

class AdminStatusTest {
	
 @Test
public 	void test() 
 {
	
	 
		
       AdminStatus astest=new AdminStatus("8063516","recruited","not well");
       IndividualDAO i=new IndividualDAO("8063516","recruited","not well");
	 
		
		 Assert.assertEquals(astest,i.actualData());
		 
		  
	 }
	 
	 
	}


