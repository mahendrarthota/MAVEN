package com.virtusa.vrps.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.virtusa.vrps.DAO.ApplicationDAO;
import com.virtusa.vrps.DAO.Individual1DAO;
import com.virtusa.vrps.DAO.Individual3DAO;
import com.virtusa.vrps.models.Application;
import com.virtusa.vrps.models.Applied;

class ApplicationTest {

	@Test
	void test() {
		Application astest=new Application("8063516","mouli","reddy","annapareddy","annapareddymoulim@gmail.com","8008703460","B.E/B.Tech","77","Intermediate","92","S.S.C","88","2019-07-23","teir2","Employed");
	       Individual3DAO i=new Individual3DAO("8063516","mouli","reddy","annapareddy","annapareddymoulim@gmail.com","8008703460","B.E/B.Tech","77","Intermediate","92","S.S.C","88","2019-07-23","teir2","Employed");
		 
			
			 Assert.assertEquals(astest,i.actualData());












		 
	}

}
