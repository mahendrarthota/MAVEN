package com.virtusa.vrps.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import com.virtusa.vrps.models.Application;

public class ApplicationDAO {
	public ArrayList<Application> getAllApply() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from Applicationtable2";
		ArrayList<Application> Employees = new ArrayList<Application>();
		try (Connection con = Dbutils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			while (rs.next()) {
				String id = rs.getString(1);
				String firstname = rs.getString(2);
				String middlename = rs.getString(3);
				String lastname = rs.getString(4);
				String email= rs.getString(5);
				String phone = rs.getString(6);
				String degree = rs.getString(7);
				String degreemarks = rs.getString(8);
				String inter = rs.getString(9);
				String intermarks= rs.getString(10);
				String tenth= rs.getString(11);
				String tenthmarks = rs.getString(12);
				String availdate = rs.getString(13);
				String jobslevel= rs.getString(14);
				String jobstatus= rs.getString(15);
				Application s = new Application(id, firstname, middlename,lastname , email, phone,degree,degreemarks,inter,intermarks,tenth,tenthmarks,availdate,jobslevel,jobstatus);
				Employees.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return Employees;
	}


}
