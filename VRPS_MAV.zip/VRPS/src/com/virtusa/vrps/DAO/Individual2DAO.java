package com.virtusa.vrps.DAO;

import java.util.ArrayList;

import com.virtusa.vrps.models.Employee;

public class Individual2DAO 
{

		 int id;
		 String name;
		 String UserName;
		 String Password;
		 String email;
		 String phone;
		 String address;
		 int roleid;
		 int id1;
		 String name1;
		 String UserName1;
		 String Password1;
		 String email1;
		 String phone1;
	 String address1;
	 int roleid1;
		 public Individual2DAO(int id, String name, String userName, String password, String email, String phone,
				String address, int roleid) {
			super();
			this.id = id;
			this.name = name;
			UserName = userName;
			Password = password;
			this.email = email;
			this.phone = phone;
			this.address = address;
			this.roleid = roleid;
		}
		
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUserName() {
	return UserName;
}
public void setUserName(String userName) {
	UserName = userName;
}
public String getPassword() {
	return Password;
}
public void setPassword(String password) {
	Password = password;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public int getRoleid() {
	return roleid;
}
public void setRoleid(int roleid) {
	this.roleid = roleid;
}

public void display() {
	EmployeeDAO asd=new EmployeeDAO();
	ArrayList <Employee> as= asd.getAll();	
	for(int i=0;i<as.size();i++) {
		System.out.println(as.get(i));
		
	}
}
public Employee actualData() 
{
	int j=0;
	EmployeeDAO asd=new EmployeeDAO();
	ArrayList <Employee> as= asd.getAll();
	 for(int i=0;i<as.size();i++)
	 {
	 if(getId()==(as.get(i).getId()))
	 {
	id1 = getId();
	j++;
	 }
	 else id1=0;
	 if(getName().equals(as.get(i).getName()))
	 {
	name1=getName();
	j++;
	 }
	 else
		 name1=null;
	 
	
	 
	 
	 if(getUserName().equals(as.get(i).getUserName()))
	 {
	UserName1=getUserName();
	j++;
	 }
	 else
		 UserName1=null;
	 
	 
	 
	 
	 if(getPassword().equals(as.get(i).getPassword()))
	 {
	Password1=getPassword();
	j++;
	 }
	 
	 else Password1=null;
	 if(getEmail().equals(as.get(i).getEmail()))
	 {
	email1=getEmail();
	j++;
	 }
	 else
		 email1=null;
	 if(getPhone().equals(as.get(i).getPhone()))
	 {
	phone1=getPhone();
	j++;
	 }
	 else
		 phone1=null;
	 if(getAddress().equals(as.get(i).getAddress()))
	 {
	address1=getAddress();
	j++;
	 }
	 else
		 address1=null;
	 if(getRoleid()==(as.get(i).getRoleid()))
	 {
	roleid1=getRoleid();
	j++;
	 }
	 else
		 roleid1=0;
	 if(j==8)
		 break;
	 }
	 
	 
	 
	 return new Employee(id1,name1,UserName1,Password1,email1,phone1,address1,roleid1);
}
}
